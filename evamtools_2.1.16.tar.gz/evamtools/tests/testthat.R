library(testthat)
library(evamtools)

test_check("evamtools")

