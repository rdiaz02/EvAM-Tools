## Testing HyperHMM

t1 <- Sys.time()
test_that("Testing HyperHMM integration in EvAM-Tools", {

    ## For testing
    
})

cat("\n Done test.HyperHMM.R. Seconds = ",
    as.vector(difftime(Sys.time(), t1, units = "secs")), "\n")
