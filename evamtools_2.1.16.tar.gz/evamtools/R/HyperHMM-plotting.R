library(ggplot2)
library(ggrepel)
library(igraph)
library(stringr)

plot.bubbles <- function(stats.df, labels = NULL) {
  message("Building bubble plot")
  bp.df <- stats.df
  bp.df$prob <- bp.df$mean
  ## plot bubbles
  if(is.null(labels)) {
    g.1 <- ggplot(bp.df, aes(x=order, y=feature)) + geom_point(aes(size=prob), colour="#CCCCCC") + theme_classic() + theme(legend.position = "none")
  } else {
    g.1 <- ggplot(bp.df, aes(x=order, y=feature)) + geom_point(aes(size=prob), colour="#CCCCCC") + scale_y_continuous(breaks=length(labels):1, labels=labels) + theme_classic() + theme(legend.position = "none")
  }
  g.1
}

# plot graph of ordered pair acquisitions
plot.pfg <- function(viz.tl,              # list of transitions between states
                    pfg.layout = "matrix",  # graph loyout
                    curvature = 1           # geometric parameter for edge curviness
                    ) {
  translist <- viz.tl
  message("Building PFG")
  ## PFG
  # get the set of pairwise first-next feature labels throughout each pathway
  edges <- data.frame()
  message("Reading")
  zeroes <- strsplit(translist[1], split=" ")[[1]][1]
  for(i in 1:1000) {
    #print(i)
    # get source and destination states
    src <- strsplit(translist[i], " ")[[1]][1]
    dest <- strsplit(translist[i], " ")[[1]][2]
    srcn <- as.numeric(strsplit(src, "")[[1]])
    destn <- as.numeric(strsplit(dest, "")[[1]])
    # identify changed feature
    change <- which(srcn-destn != 0)
    # add this and last change to list of ordered pairs
    if(length(change) == 1) {
      if(src != zeroes) {
        edges <- rbind(edges, data.frame(src=lastchange, dest=change))
      } else {
        edges <- rbind(edges, data.frame(src=0, dest=change))
      }
      lastchange <- change
    }
  }
  # get unique edges in this adjacency list and counts
  uedges <- unique(edges)
  ucount <- 0*uedges$src
  for(i in 1:nrow(uedges)) {
    ucount[i] <- length(which(edges$src == uedges$src[i] & edges$dest == uedges$dest[i]))
  }
  
  message("Building adj mat")
  # construct graph from these edges
  uedges <- rbind(uedges, uedges[1,])
  ucount[length(ucount)+1] <- 1
  g <- graph.data.frame(uedges)
  E(g)$weight <- ucount
  maxw <- max(ucount)
  sumw <- sum(ucount)
  
  # sort nodes to a canonical order -- helps when we're comparing different cases, especially with the matrix layout
  s <- mixedsort(names(V(g)))
  new.g <- igraph::permute(g, match(V(g)$name, s))
  g <- new.g
  V(g)$name[1] <- "-"
  
  message("Building plot")
  # plot PFG
  if(pfg.layout == "tree") {
    g.3 <- ggraph(g, layout="tree") + geom_edge_bend(aes(edge_width=exp(weight/sumw), edge_alpha = weight/sumw), strength=curvature,  arrow=arrow()) + geom_node_point() + geom_node_label(aes(label=name), nudge_x = 0.05, nudge_y=-0.05) + theme_void() + theme(legend.position = "none")
  } else if(pfg.layout == "matrix") {
    g.3 <- ggraph(g, layout="matrix") + geom_edge_bend(aes(edge_width=exp(weight/sumw), edge_alpha = weight/sumw), strength=curvature,  arrow=arrow()) + geom_node_point() + geom_node_label(aes(label=name), nudge_x = 0.05, nudge_y=-0.05) + theme_void() + theme(legend.position = "none")
  } else {
    g.3 <- ggraph(g) + geom_edge_bend(aes(edge_width=exp(weight/sumw), edge_alpha = weight/sumw), strength=curvature,  arrow=arrow()) + geom_node_point() + geom_node_label(aes(label=name), nudge_x = 0.05, nudge_y=-0.05) + theme_void() + theme(legend.position = "none")
  }
  g.3
}

# binary to decimal function
BinToDec <- function(x) {
  sum(2^(which(rev(unlist(strsplit(as.character(x), "")) == 1))-1))
}

plot.hypercube <- function(viz.tl,                  # set of transitions
                           use.width = TRUE,        # use line width to display edge weights?
                           duplicate.offset = 0.,   # vertical offset for nodes in identical positions
                           lab.size = 3,            # size for edge labels
                           p.size = 1,              # point size
                           node.labels = TRUE,      # node labels, yes or no?
                           seg.labels = TRUE,       # line segment labels?
                           threshold = 0,           # ignore edges under a threshold in the hypercube plot
                           break.redundancy = 0,    # itself redundant now?
                           rotate.phi = FALSE       # rotate states out of the page (in case of trajectories bunched up near the top/bottom)
) {
  transitions <- viz.tl
  message("Building hypercube plot")  
  
  ## hypercube
  # get unique set of transitions and associated counts
  l <- unique(translist)
  counts <- rep(0, length(l))
  for(i in 1:length(l)) {
    set <- which(translist == l[i])
    counts[i] <- length(set)
  }
  #  l <- l[counts > threshold]
  
  # split into lists of source and destination nodes
  srcs <- dests <- list()
  n <- 1
  for(line in l) {
    s <- strsplit(line, " ")
    srcs[[n]] <- s[[1]][1]
    dests[[n]] <- s[[1]][2]
    n <- n + 1
  }
  # set string length and 0^L string
  len <- nchar(srcs[[1]]) 
  zero <- paste(rep("0", len), collapse="")
  
  # produce useful vectors
  srcs <- unlist(srcs)
  dests <- unlist(dests)
  
  all.nodes <- apply(expand.grid(rep(list(0:1),len)), 1, paste, collapse="")
  nodes <- all.nodes
  nnodes <- length(nodes)
  
  # produce list storing where incoming edges to each node come from
  ins <- list()
  for(node in nodes) {
    refs <- which(dests == node)
    refcodes <- srcs[refs]
    ins[[length(ins)+1]] <- which(nodes %in% refcodes)
  }
  
  # produce hypercube visualisation
  
  message("Calculating embedding")
  # spherical polars: r, theta, phi
  # r = 1 everywhere
  rs <- rep(1, nnodes)
  # theta is just set by number of 1s in a string
  
  thetas <- unlist(lapply(nodes, function(s) { return(str_count(s, "0")*3.14159/len) }) )
  
  # initialise phis
  phis <- rep(-1, nnodes)
  zero.counts <- unlist(lapply(nodes, function(s) { return(str_count(s, "0")) }) )
  for(zeroes in 0:len) {
    refs <- which(zero.counts == zeroes)
    these.phis <- (0:(length(refs)-1))/length(refs)*3.14159
    phis[refs] <- these.phis
  }
  
  # dataframes for spherical and cartesian coordinates
  spcoords <- data.frame(r = rs, theta = thetas, phi = phis, label = nodes)
  # rotate phi values if required
  if(rotate.phi == TRUE) {
    spcoords$phi <- spcoords$phi + 3.14159/2
  }
  
  coords <- data.frame(x = spcoords$r*cos(spcoords$phi)*sin(spcoords$theta), y = spcoords$r*sin(spcoords$phi)*sin(spcoords$theta), z = spcoords$r*cos(spcoords$theta), label = spcoords$label)
  
  # dataframe for line segments in cartesian coords
  segments <- data.frame()
  seglabels <- data.frame()
  safe.nodes <- rep(FALSE, nrow(coords))
  for(i in 1:length(srcs)) {
    if(counts[i] > threshold) {
      src <- which(coords$label == srcs[i])
      dest <- which(coords$label == dests[i])
      safe.nodes[src] <- safe.nodes[dest] <- TRUE
      label <- paste(c("+", which(unlist(strsplit(srcs[i], split="")) !=unlist(strsplit(dests[i], split="")))), collapse="")
      segment <- data.frame(src.x = coords[src,]$x, src.y = coords[src,]$y, src.z = coords[src,]$z, dest.x = coords[dest,]$x, dest.y = coords[dest,]$y, dest.z = coords[dest,]$z, count=counts[i])
      segments <- rbind(segments, segment)
      seglabels <- rbind(seglabels, data.frame(x = (segment$src.x + segment$dest.x)/2, y = (segment$src.y + segment$dest.y)/2,  z = (segment$src.z + segment$dest.z)/2, label=label))
    }
  }
  
  base <- data.frame(src.x=0,src.z=0,dest.x=0,dest.z=0,count=0)
  
  message("Make plot")
  # plot
  if(use.width) {
    cube.plot <- ggplot() +
      geom_segment(data=segments, aes(x=src.z, y=src.x, xend=dest.z, yend=dest.x, size=count/max(count)), color="#CCCCCC") +
      scale_size_identity() +
      geom_point(data = coords[safe.nodes == TRUE,], aes(x=z, y=x), size=p.size, color="#444444") +
      xlim(-1,1) + ylim(-1,1) + theme_void() + theme(legend.position="none")
    if(node.labels == TRUE) { cube.plot <- cube.plot + geom_text_repel(data = coords[safe.nodes == TRUE,], aes(x=z,y=x,label=label)) }
    if(seg.labels == TRUE) {cube.plot <- cube.plot + geom_text(data=seglabels, aes(x=z,y=x,label=label), color="#888888", size=lab.size) }
  } else {
    cube.plot <- ggplot() +
      geom_segment(data=segments, aes(x=src.z, y=src.x, xend=dest.z, yend=dest.x), color="#CCCCCC") +
      geom_point(data = coords[safe.nodes == TRUE,], aes(x=z, y=x), size=p.size, color="#444444") +
      xlim(-1,1) + ylim(-1,1) + theme_void() + theme(legend.position="none")
    if(node.labels == TRUE) { cube.plot <- cube.plot + geom_text_repel(data = coords[safe.nodes == TRUE,], aes(x=z,y=x,label=label)) }
    if(seg.labels == TRUE) { cube.plot <- cube.plot + geom_text(data=seglabels, aes(x=z,y=x,label=label), color="#888888", size=lab.size) }
    
  }
  return(cube.plot)
}